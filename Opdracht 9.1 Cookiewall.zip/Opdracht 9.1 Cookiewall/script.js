function openModal() {
    document.getElementById('cookiewallModal').style.display = 'block';
    document.getElementById('overlay').style.display = 'block';
  }
  
  function verifieerLeeftijd() {
    var leeftijd = document.getElementById('leeftijdInput').value;
  
    if (leeftijd && parseInt(leeftijd) >= 18) {
      // Redirect naar een willekeurige website (vervang 'https://www.example.com' door de gewenste URL)
      window.location.href = 'https://www.example.com';
    } else {
      // Toon rode pagina met foutmelding
      document.body.innerHTML = '<div style="text-align: center; padding: 50px; background-color: #ff9999;">'
        + '<h1>Helaas, je bent te jong</h1>'
        + '</div>';
    }
  }
  